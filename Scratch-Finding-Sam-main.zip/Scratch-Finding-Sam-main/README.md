# Finding My Friend, Sam 🔍
**Platform:** Scratch 3.0 (.sb3)  
**Category:** Interactive Narrative / Logic Design

### 📝 Project Overview
"Finding My Friend, Sam" is an interactive logic-based project. It demonstrates the use of:
* **Event-Driven Programming:** Coordinating multiple "sprites" and backdrops through broadcast messaging.
* **Variable Management:** Tracking game states and user progress.
* **Multimedia Integration:** Implementing custom audio cues and vector graphics for an immersive user experience.

### 🚀 How to Run the Project
Since `.sb3` files are specific to the Scratch environment, you can view the project by following these steps:

1. **Download** the `Finding My Friend , Sam.sb3` file from this repository.
2. Open the **[Scratch Online Editor](https://scratch.mit.edu/editor)**.
3. Select **File** > **Load from your computer**.
4. Select the `.sb3` file you just downloaded.

### 💡 Academic Value
While a creative project, this represents foundational concepts in **Computational Thinking**, including state machines and conditional branching, which are core to understanding complex system behaviors in Cybersecurity.
